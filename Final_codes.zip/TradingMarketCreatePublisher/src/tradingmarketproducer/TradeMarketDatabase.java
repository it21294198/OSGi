package tradingmarketproducer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TradeMarketDatabase implements ITradingMarketDB {

    private File userCsvFile;
    private File companyCsvFile;
    
    @Override
    public String databaseRunner() {
        String documentsPath = System.getProperty("user.home") + File.separator + "Documents";
        String userCsvFilePath = documentsPath + File.separator + "users.csv";
        String companyCsvFilePath = documentsPath + File.separator + "company.csv";

        userCsvFile = new File(userCsvFilePath);
        companyCsvFile = new File(companyCsvFilePath);

        try {
            // Create the user CSV file if it doesn't exist
            if (!userCsvFile.exists()) {
                if (!userCsvFile.getParentFile().exists()) {
                    userCsvFile.getParentFile().mkdirs();
                }
                userCsvFile.createNewFile();
            }
            
            // Create the company CSV file if it doesn't exist
            if (!companyCsvFile.exists()) {
                if (!companyCsvFile.getParentFile().exists()) {
                    companyCsvFile.getParentFile().mkdirs();
                }
                companyCsvFile.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error: Failed to create CSV files.";
        }

        // If both CSV files exist and were successfully created, return success message
        return "Database is running On TradingMarketPublisher";
    }

	@Override
	public boolean createNewUser(String uname) {
		// create new user for -> UserId | UserName | CompanyId |   NoOfStocks for user.csv
        try {
            FileWriter writer = new FileWriter(userCsvFile, true); // true for appending to the file
            int userId = generateUserId(); // Generate a unique user ID
            String line = userId + "," + uname + ",0,0\n"; // Assuming initial CompanyId and NoOfStocks are 0
            writer.write(line);
            writer.close();
            return true; // User creation successful
        } catch (IOException e) {
            e.printStackTrace();
            return false; // User creation failed
        }
	}

	@Override
	public boolean addMockData() {
//		company.csv -> | CompanyId | companyName | NoOfStocks | PerPrice | NoOfHolders |
        try {
            FileWriter writer = new FileWriter(companyCsvFile, true); // true for appending to the file
            // Example mock data
            String line = "1,CompanyA,100,10.0,0\n" + // CompanyA with 100 stocks, priced at $10 each, 0 holders
                          "2,CompanyB,200,20.0,0\n" +
                          "3,CompanyC,300,30.0,0\n" +
                          "4,CompanyD,400,40.0,0\n" ;  // CompanyB with 200 stocks, priced at $20 each, 0 holders
            writer.write(line);
            writer.close();
            return true; // Mock data addition successful
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Mock data addition failed
        }

	}
	
	@Override
    public boolean addMockUsers() {
        try {
            FileWriter writer = new FileWriter(userCsvFile, true); // true for appending to the file
            String line = "1,John Doe,0,0\n" +
                          "2,Jane Smith,0,0\n" + 
                          "3,Alice Johnson,0,0\n" + 
                          "4,Bob Brown,0,0\n"; 

            writer.write(line);
            writer.close();
            return true; // Mock user addition successful
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Mock user addition failed
        }
    }
	
	@Override
	public boolean createNewCompany(String companyName, int noOfStocks, double perPrice) {
	    try {
	        FileWriter writer = new FileWriter(companyCsvFile, true); // true for appending to the file
	        int companyId = getLastCompanyId(); // Generate a unique company ID
	        String line = companyId + "," + companyName + "," + noOfStocks + "," + perPrice + ",0\n"; // Assuming initial NoOfHolders is 0
	        writer.write(line);
	        writer.close();
	        return true;
	    } catch (IOException e) {
	        e.printStackTrace();
	        return false; // Company creation failed
	    }
	}
	
    private int generateUserId() {
    	try {
            BufferedReader reader = new BufferedReader(new FileReader(userCsvFile));
            String line;
            int lastUserId = 0;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int userId = Integer.parseInt(parts[0]);
                if (userId > lastUserId) {
                    lastUserId = userId;
                }
            }
            reader.close();
            return lastUserId + 1; // Increment last user ID by 1
        } catch (IOException e) {
            e.printStackTrace();
            return -1; // Return -1 if reading the file fails
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return -1; // Return -1 if parsing the user ID fails
        }
    }

    private int getLastCompanyId() throws IOException {
        int lastCompanyId = 0;
        BufferedReader reader = new BufferedReader(new FileReader(companyCsvFile));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            int companyId = Integer.parseInt(parts[0]);
            if (companyId > lastCompanyId) {
                lastCompanyId = companyId;
            }
        }
        reader.close();
        return lastCompanyId;
    }

}
