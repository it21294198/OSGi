package tradingmarketproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class TradingActivator implements BundleActivator {

    private ServiceRegistration<TradeMarketDatabase> publishServiceRegistration;
	
	public void start(BundleContext context) throws Exception {
        
        TradeMarketDatabase publisherTradingMarketService = new TradeMarketDatabase();
        publishServiceRegistration = context.registerService(TradeMarketDatabase.class, publisherTradingMarketService, null);
        
        System.out.println("TradingMarket Database Publisher start");

	}

	public void stop(BundleContext context) throws Exception {
	
        if (publishServiceRegistration != null) {
            publishServiceRegistration.unregister();
        }
        System.out.println("TradingMarket Database Publisher stop");

	}
	
}
