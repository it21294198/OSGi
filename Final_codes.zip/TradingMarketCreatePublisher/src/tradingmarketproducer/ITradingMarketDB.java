package tradingmarketproducer;

public interface ITradingMarketDB {
	
	// check db connection and add mock data to db 
	String databaseRunner();
	
	boolean addMockData();
	
	boolean addMockUsers();
	
	boolean createNewUser(String uname);
	
	boolean createNewCompany(String companyName, int noOfStocks, double perPrice);

}
