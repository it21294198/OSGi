package tradingmarketproducer;

public class Company {
	
	private int CompanyId;
	private String CompanyName;
	private int NoOfStocks;
	private double PerPrice;
	private int NoOfHolders;
	
	public Company(int companyId, String companyName, int noOfStocks, double perPrice, int noOfHolders) {
		super();
		CompanyId = companyId;
		CompanyName = companyName;
		NoOfStocks = noOfStocks;
		PerPrice = perPrice;
		NoOfHolders = noOfHolders;
	}
	
	public int getCompanyId() {
		return CompanyId;
	}
	public void setCompanyId(int companyId) {
		CompanyId = companyId;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public int getNoOfStocks() {
		return NoOfStocks;
	}
	public void setNoOfStocks(int noOfStocks) {
		NoOfStocks = noOfStocks;
	}
	public double getPerPrice() {
		return PerPrice;
	}
	public void setPerPrice(double perPrice) {
		PerPrice = perPrice;
	}
	public int getNoOfHolders() {
		return NoOfHolders;
	}
	public void setNoOfHolders(int noOfHolders) {
		NoOfHolders = noOfHolders;
	}

}
