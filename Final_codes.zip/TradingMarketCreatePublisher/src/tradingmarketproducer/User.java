package tradingmarketproducer;

public class User {

	private int UserId;
	private String UserName;
	private int CompanyId;
	private int NoOfStocks;
	
	public User(int userId, String userName, int companyId, int noOfStocks) {
		super();
		UserId = userId;
		UserName = userName;
		CompanyId = companyId;
		NoOfStocks = noOfStocks;
	}

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public int getCompanyId() {
		return CompanyId;
	}

	public void setCompanyId(int companyId) {
		CompanyId = companyId;
	}

	public int getNoOfStocks() {
		return NoOfStocks;
	}

	public void setNoOfStocks(int noOfStocks) {
		NoOfStocks = noOfStocks;
	}
	
}
