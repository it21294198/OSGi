package tradingmarketstatusproducer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import tradingmarketproducer.Company;
import tradingmarketproducer.User;

public class StatusDatabase implements IStatusPublisher {

    private File userCsvFile;
    private File companyCsvFile;
    
	@Override
    public String databaseRunner() {
        String documentsPath = System.getProperty("user.home") + File.separator + "Documents";
        String userCsvFilePath = documentsPath + File.separator + "users.csv";
        String companyCsvFilePath = documentsPath + File.separator + "company.csv";

        userCsvFile = new File(userCsvFilePath);
        companyCsvFile = new File(companyCsvFilePath);

        try {
            // Create the user CSV file if it doesn't exist
            if (!userCsvFile.exists()) {
                if (!userCsvFile.getParentFile().exists()) {
                    userCsvFile.getParentFile().mkdirs();
                }
                userCsvFile.createNewFile();
            }
            
            // Create the company CSV file if it doesn't exist
            if (!companyCsvFile.exists()) {
                if (!companyCsvFile.getParentFile().exists()) {
                    companyCsvFile.getParentFile().mkdirs();
                }
                companyCsvFile.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error: Failed to create CSV files.";
        }

        // If both CSV files exist and were successfully created, return success message
        return "Database is running On TradingMarketStatusPublisher";
    }

    @Override
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(userCsvFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int userId = Integer.parseInt(parts[0]);
                String userName = parts[1];
                int companyId = Integer.parseInt(parts[2]);
                int noOfStocks = Integer.parseInt(parts[3]);
                userList.add(new User(userId, userName, companyId, noOfStocks));
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userList;
    }

    @Override
    public List<Company> getAllCompanies() {
        List<Company> companyList = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(companyCsvFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int companyId = Integer.parseInt(parts[0]);
                String companyName = parts[1];
                int noOfStocks = Integer.parseInt(parts[2]);
                double perPrice = Double.parseDouble(parts[3]);
                int noOfHolders = Integer.parseInt(parts[4]);
                companyList.add(new Company(companyId, companyName, noOfStocks, perPrice, noOfHolders));
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return companyList;
   }

}
