package tradingmarketstatusproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class StatusActivator implements BundleActivator {

    private ServiceRegistration<StatusDatabase> publishServiceRegistration;
	
	public void start(BundleContext context) throws Exception {
        
        StatusDatabase publisherStatusService = new StatusDatabase();
        publishServiceRegistration = context.registerService(StatusDatabase.class, publisherStatusService, null);
        
        System.out.println("Status Database Publisher start");

	}

	public void stop(BundleContext context) throws Exception {
	
        if (publishServiceRegistration != null) {
            publishServiceRegistration.unregister();
        }
        System.out.println("Status Database Publisher stop");

	}

}
