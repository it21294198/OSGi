package tradingmarketstatusproducer;

import java.util.List;

import tradingmarketproducer.Company;
import tradingmarketproducer.User;

public interface IStatusPublisher {
	
	String databaseRunner();

	// get all users status -->> UserId | UserName | CompanyId |   #Stocks
	List<User> getAllUsers();
	
	// get all company status -->> CompanyId | companyName | #Stocks | PerPrice | #Holders
	List<Company> getAllCompanies();

}
