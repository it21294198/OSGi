package tradingmarketbuyerproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class BuyerActivator implements BundleActivator {

    private ServiceRegistration<BuyerDatabase> publishServiceRegistration;
	
	public void start(BundleContext context) throws Exception {
        
        BuyerDatabase publisherBuyerService = new BuyerDatabase();
        publishServiceRegistration = context.registerService(BuyerDatabase.class, publisherBuyerService, null);
        
        System.out.println("Buyer Database Publisher start");

	}

	public void stop(BundleContext context) throws Exception {
	
        if (publishServiceRegistration != null) {
            publishServiceRegistration.unregister();
        }
        System.out.println("Buyer Database Publisher stop");

	}

}
