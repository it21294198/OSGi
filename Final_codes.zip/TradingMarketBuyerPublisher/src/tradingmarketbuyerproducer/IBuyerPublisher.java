package tradingmarketbuyerproducer;

public interface IBuyerPublisher {

	String databaseRunner();
	
	boolean buyStocks(int buyerId,int sellerId,int companyId,int noOfStocks);

}	

