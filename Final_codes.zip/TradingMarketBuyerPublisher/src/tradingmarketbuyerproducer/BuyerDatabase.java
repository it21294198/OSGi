package tradingmarketbuyerproducer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BuyerDatabase implements IBuyerPublisher {

    private File userCsvFile;
    private File companyCsvFile;
    
	@Override
	public String databaseRunner() {
        String documentsPath = System.getProperty("user.home") + File.separator + "Documents";
        String userCsvFilePath = documentsPath + File.separator + "users.csv";
        String companyCsvFilePath = documentsPath + File.separator + "company.csv";

        userCsvFile = new File(userCsvFilePath);
        companyCsvFile = new File(companyCsvFilePath);

        try {
            // Create the user CSV file if it doesn't exist
            if (!userCsvFile.exists()) {
                if (!userCsvFile.getParentFile().exists()) {
                    userCsvFile.getParentFile().mkdirs();
                }
                userCsvFile.createNewFile();
            }
            
            // Create the company CSV file if it doesn't exist
            if (!companyCsvFile.exists()) {
                if (!companyCsvFile.getParentFile().exists()) {
                    companyCsvFile.getParentFile().mkdirs();
                }
                companyCsvFile.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error: Failed to create CSV files.";
        }

        // If both CSV files exist and were successfully created, return success message
        return "Database is running On TradingMarketBuyerPublisher";
    }

	@Override
	public boolean buyStocks(int buyerId, int sellerId, int companyId, int noOfStocks) {
        try {
            // Read existing user data from users.csv
            List<String> lines = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new FileReader(userCsvFile));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();

            // Update the number of stocks for buyer and seller
            boolean buyerFound = false, sellerFound = false;
            FileWriter writer = new FileWriter(userCsvFile);
            for (String userLine : lines) {
                String[] parts = userLine.split(",");
                int userId = Integer.parseInt(parts[0]);
                if (userId == buyerId) {
                    int currentStocks = Integer.parseInt(parts[3]);
                    parts[3] = String.valueOf(currentStocks + noOfStocks); // Add stocks to buyer
                    buyerFound = true;
                } else if (userId == sellerId) {
                    int currentStocks = Integer.parseInt(parts[3]);
                    parts[3] = String.valueOf(currentStocks - noOfStocks); // Subtract stocks from seller
                    sellerFound = true;
                }
                writer.write(String.join(",", parts) + "\n");
            }
            writer.close();

            // If both buyer and seller are found and updated, return true
            return buyerFound && sellerFound;
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Error occurred while updating user data
        }
    }

}
