package tradingmarketcalculatorpublisher;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class CalculatorActivator implements BundleActivator {

    private ServiceRegistration<Calculator> publishServiceRegistration;
	
	public void start(BundleContext context) throws Exception {
        
		Calculator publisherBuyerService = new Calculator();
        publishServiceRegistration = context.registerService(Calculator.class, publisherBuyerService, null);
        
        System.out.println("Calculator Publisher start");

	}

	public void stop(BundleContext context) throws Exception {
	
        if (publishServiceRegistration != null) {
            publishServiceRegistration.unregister();
        }
        System.out.println("Calculator Publisher stop");

	}

}
