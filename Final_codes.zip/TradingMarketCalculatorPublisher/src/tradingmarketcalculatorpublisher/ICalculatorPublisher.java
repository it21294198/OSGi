package tradingmarketcalculatorpublisher;

public interface ICalculatorPublisher {
	
	String databaseRunner();
	
	public boolean deleteUser(int userId);
	
	float getAnnualInterestValue(float value,float rate);
	
	float getMonthlyInterestValue(float value,int noOfMonths,float rate);
	
}
