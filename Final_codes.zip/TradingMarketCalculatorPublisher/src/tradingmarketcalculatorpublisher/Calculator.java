package tradingmarketcalculatorpublisher;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import tradingmarketproducer.User;

public class Calculator implements ICalculatorPublisher {

    private File userCsvFile;
    private File companyCsvFile;
    
    @Override
    public String databaseRunner() {
        String documentsPath = System.getProperty("user.home") + File.separator + "Documents";
        String userCsvFilePath = documentsPath + File.separator + "users.csv";
        String companyCsvFilePath = documentsPath + File.separator + "company.csv";

        userCsvFile = new File(userCsvFilePath);
        companyCsvFile = new File(companyCsvFilePath);

        try {
            // Create the user CSV file if it doesn't exist
            if (!userCsvFile.exists()) {
                if (!userCsvFile.getParentFile().exists()) {
                    userCsvFile.getParentFile().mkdirs();
                }
                userCsvFile.createNewFile();
            }
            
            // Create the company CSV file if it doesn't exist
            if (!companyCsvFile.exists()) {
                if (!companyCsvFile.getParentFile().exists()) {
                    companyCsvFile.getParentFile().mkdirs();
                }
                companyCsvFile.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error: Failed to create CSV files.";
        }

        // If both CSV files exist and were successfully created, return success message
        return "Database is running On TradingMarketPublisher";
    }
    
    @Override
    public boolean deleteUser(int userId) {
        try {
            // Ensure userCsvFile is initialized
            if (userCsvFile == null) {
                databaseRunner(); // Initialize userCsvFile
            }

            List<User> userList = getAllUsers();
            boolean found = false;
            Iterator<User> iterator = userList.iterator();
            while (iterator.hasNext()) {
                User user = iterator.next();
                if (user.getUserId() == userId) {
                    iterator.remove();
                    found = true;
                    break;
                }
            }
            if (found) {
                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter(userCsvFile));
                    for (User user : userList) {
                        writer.write(user.getUserId() + "," + user.getUserName() + "," + user.getCompanyId() + "," + user.getNoOfStocks() + "\n");
                    }
                    writer.close();
                    return true;
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            } else {
                System.out.println("User with ID " + userId + " not found.");
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    private List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(userCsvFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int userId = Integer.parseInt(parts[0]);
                String userName = parts[1];
                int companyId = Integer.parseInt(parts[2]);
                int noOfStocks = Integer.parseInt(parts[3]);
                userList.add(new User(userId, userName, companyId, noOfStocks));
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userList;
    }
        
	@Override
	public float getAnnualInterestValue(float value, float rate) {
		return rate * value * 12;
	}

	@Override
	public float getMonthlyInterestValue(float value, int noOfMonths, float rate) {
		return rate * noOfMonths * value;
	}

}
