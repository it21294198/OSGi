package tradingmarketstatusconsumer;

import java.util.List;
import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import tradingmarketproducer.Company;
import tradingmarketproducer.User;
import tradingmarketstatusproducer.StatusDatabase;

public class Activator implements BundleActivator {

    private ServiceReference<StatusDatabase> serviceStatusReference;

    private Scanner scanner;

    public void start(BundleContext bundleContext) throws Exception {
        System.out.println("Start subscriber service");
        
		try {
			
			serviceStatusReference = bundleContext.getServiceReference(StatusDatabase.class);
			StatusDatabase statusDatabase = null;
			if (serviceStatusReference != null) {
			    statusDatabase = bundleContext.getService(serviceStatusReference);
			}
	
	        if (statusDatabase != null) {
	            System.out.println("Connected to Status service.");
	        } else {
	            System.out.println("Status service not available.");
	        }
        
        scanner = new Scanner(System.in);
		System.out.println(statusDatabase.databaseRunner());

        String userInput;
        while (true) {
            System.out.println("\u001B[1m\u001B[33m============ Welcome To MiniTradingMarket =============\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 1 to Register\u001B[0m");
            System.out.println("\u001B[1m\u001B[31mEnter any character to Quit\u001B[0m");
            System.out.println("\u001B[1m\u001B[33m=======================================================\u001B[0m");
            System.out.print("\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            userInput = scanner.nextLine();

            if (userInput.equalsIgnoreCase("1")) {

            	System.out.println("\t"+"\u001B[1m\u001B[29m============$$$$$$$$ Today Market $$$$$$$$=============\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 1 to See all Companies\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 2 to See all Users\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 3 to Check Connection\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[29m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputStatus;
            	userInputStatus = scanner.nextLine();
            		if(userInputStatus.equalsIgnoreCase("1")) {
            			try {				
	            			List<Company> companyList = statusDatabase.getAllCompanies();
	                     	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
	                     	System.out.println("\u001B[1m\u001B[29mCompanyId | CompanyName | #Stocks | PerPrice | #Holders\u001B[0m");
	            			for (Company company : companyList) {
	            	            System.out.print("\t"+company.getCompanyId()+ "\t");
	            	            System.out.print(company.getCompanyName()+ "\t");
	            	            System.out.print(company.getNoOfStocks()+ "\t");
	            	            System.out.print(company.getPerPrice()+ "\t");
	            	            System.out.print(company.getNoOfHolders());
	            	            System.out.println();
	            	        }
	                    	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
            			}catch(Exception e) {
            				e.printStackTrace();
            			}
            		}else if(userInputStatus.equalsIgnoreCase("2")) {
            			List<User> userList = statusDatabase.getAllUsers();
                    	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
                     	System.out.println("\u001B[1m\u001B[29m	 UserId |  UserName  |  CompanyId  |  Number of Stocks\u001B[0m");
            			for (User user : userList) {
            	            System.out.print("\t"+user.getUserId()+ "\t");
            	            System.out.print(user.getUserName()+ "\t");
            	            System.out.print(user.getCompanyId()+ "\t");
            	            System.out.print(user.getNoOfStocks());
            	            System.out.println();
            	        }
                    	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
             		}else if(userInputStatus.equalsIgnoreCase("3")){
            			System.out.println(statusDatabase.databaseRunner());
            		}else {
//            			break
            		}
            } else if (userInput.equalsIgnoreCase("3")) {

            } else {
                break;
            }
        	}
		}catch(Exception e) {
			e.printStackTrace();
		}
    }

    public void stop(BundleContext bundleContext) throws Exception {
    	
        if (serviceStatusReference != null) {
            bundleContext.ungetService(serviceStatusReference);
        }
        System.out.println("Stop subscriber service");
    }
}
