package tradingmarketcalculatorconsumer;

import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import tradingmarketcalculatorpublisher.Calculator;

public class Activator implements BundleActivator {

    private ServiceReference<Calculator> serviceCalculatorReference;
    
    private Scanner scanner;

	public void start(BundleContext bundleContext) throws Exception {
        System.out.println("Start Calculator subscriber service");
        
		serviceCalculatorReference = bundleContext.getServiceReference(Calculator.class);
		Calculator calculator = null;
		if (serviceCalculatorReference != null) {
			calculator = bundleContext.getService(serviceCalculatorReference);
		}

        if (calculator != null) {
            System.out.println("Connected to Calculator service.");
        } else {
            System.out.println("Calculator service not available.");
        }

        scanner = new Scanner(System.in);

        String userInput;
        while (true) {
            System.out.println("\u001B[1m\u001B[33m============ Welcome To MiniTradingMarket =============\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 1 to Calculator\u001B[0m");
            System.out.println("\u001B[1m\u001B[31mEnter any character to Quit\u001B[0m");
            System.out.println("\u001B[1m\u001B[33m=======================================================\u001B[0m");
            System.out.print("\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            userInput = scanner.nextLine();

            if (userInput.equalsIgnoreCase("1")) {
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======$$$$$$$ Chose the Calculator Type $$$$$$$=======\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 1 to Select Monthly\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 2 to Select Annual\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 3 to Delete User\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputType;
            	userInputType = scanner.nextLine();
            	
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");

            	if(userInputType.equalsIgnoreCase("1")) {
            		
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the rate (eg:-12.5) : \u001B[0m");
                	float rate;
                	rate = scanner.nextFloat();
        	        scanner.nextLine(); 
        	        
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the value (eg:-123) : \u001B[0m");
        	        float value;
        	        value = scanner.nextFloat();
        	        scanner.nextLine();
            		
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the No Of months : \u001B[0m");
            		int noOfMonths;
            		noOfMonths = scanner.nextInt();
        	        scanner.nextLine();
        	        
        	        float result = calculator.getMonthlyInterestValue(value, noOfMonths, rate);
        	        System.out.println("\t" + "\u001B[1m\u001B[36m" + result + " $ for "+noOfMonths+" months\u001B[0m");
        	    
            	}else if(userInputType.equalsIgnoreCase("2")) {
            		
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the rate (eg:-12.5) : \u001B[0m");
                	float rate;
                	rate = scanner.nextFloat();
        	        scanner.nextLine(); 
        	        
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the value (eg:-123) : \u001B[0m");
        	        float value;
        	        value = scanner.nextFloat();
        	        scanner.nextLine();
        	        
            		float result = calculator.getAnnualInterestValue(value, rate);
        	        System.out.println("\t" + "\u001B[1m\u001B[36m" + result + " $ for annually\u001B[0m");
            	}else if(userInputType.equalsIgnoreCase("3")) {
        	        System.out.print("\t" + "\u001B[1m\u001B[36mEnter UserId here To Delete : \u001B[0m");
        	  		int userId;
            		userId = scanner.nextInt();
        	        scanner.nextLine();
        	        
        	        boolean result = calculator.deleteUser(userId);
        			if(result) {
                    	System.out.println("\u001B[1m\u001B[32mUser "+userId+" is deleted\u001B[0m");
        			}else {
                    	System.out.println("\u001B[1m\u001B[31mSomething wrong happend try againg ;( \u001B[0m");
        			}
        			
            	}else {
//            		break;
            	}
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
            }else {
            	break;
            }
        }
	}

	public void stop(BundleContext bundleContext) throws Exception {
        if (serviceCalculatorReference != null) {
            bundleContext.ungetService(serviceCalculatorReference);
        }
        System.out.println("Stop Calculator subscriber service");
	}

}
