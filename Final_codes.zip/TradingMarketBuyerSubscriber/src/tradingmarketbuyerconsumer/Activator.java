package tradingmarketbuyerconsumer;

import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import tradingmarketbuyerproducer.BuyerDatabase;

public class Activator implements BundleActivator {

    private ServiceReference<BuyerDatabase> serviceBuyerReference;

    private Scanner scanner;

    public void start(BundleContext bundleContext) throws Exception {
        System.out.println("Start subscriber service");
        
		try {

			serviceBuyerReference = bundleContext.getServiceReference(BuyerDatabase.class);
			BuyerDatabase buyerDatabase = null;
			if (serviceBuyerReference != null) {
			    buyerDatabase = bundleContext.getService(serviceBuyerReference);
			}
	
	        if (buyerDatabase != null) {
	            System.out.println("Connected to Buyer service.");
	        } else {
	            System.out.println("Buyer service not available.");
	        }

        scanner = new Scanner(System.in);
		System.out.println(buyerDatabase.databaseRunner());

        String userInput;
        while (true) {
            System.out.println("\u001B[1m\u001B[33m============ Welcome To MiniTradingMarket =============\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 1 to Buy Strocks\u001B[0m");
            System.out.println("\u001B[1m\u001B[31mEnter any character to Quit\u001B[0m");
            System.out.println("\u001B[1m\u001B[33m=======================================================\u001B[0m");
            System.out.print("\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            userInput = scanner.nextLine();

            if (userInput.equalsIgnoreCase("1")) {
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======$$$$$$$$ Buying & Selling Stocks $$$$$$$$=======\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 1 to Buy Stocks\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 2 to Check Connection\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputBuyer;
            	userInputBuyer = scanner.nextLine();
            	if(userInputBuyer.equalsIgnoreCase("1")) {
            		
        	        System.out.print("\u001B[1m\u001B[36mEnter Buyer Id : \u001B[0m");
        	        int buyerId;
        	        buyerId = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        System.out.print("\u001B[1m\u001B[36mEnter Seller Id : \u001B[0m");
        	        int sellerId;
        	        sellerId = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        System.out.print("\u001B[1m\u001B[36mEnter Company Id : \u001B[0m");
        	        int companyId;
        	        companyId = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        System.out.print("\u001B[1m\u001B[36mEnter No of Stocks going to sell : \u001B[0m");
        	        int noOfStocks;
        	        noOfStocks = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        boolean result = buyerDatabase.buyStocks(buyerId, sellerId, companyId, noOfStocks);
        			if(result) {
                    	System.out.println("\u001B[1m\u001B[32mYou bought the stocks\u001B[0m");
        			}else {
                    	System.out.println("\u001B[1m\u001B[31mSomething wrong happend try againg ;( \u001B[0m");
        			}
            	}else if(userInputBuyer.equalsIgnoreCase("2")) {
            		System.out.println(buyerDatabase.databaseRunner());
            	}else {
//            		break
            	}
            } else {
                break;
            }
        	}
		}catch(Exception e) {
			e.printStackTrace();
		}
    }

    public void stop(BundleContext bundleContext) throws Exception {

        if (serviceBuyerReference != null) {
            bundleContext.ungetService(serviceBuyerReference);
        }
        System.out.println("Stop subscriber service");
    }
}
