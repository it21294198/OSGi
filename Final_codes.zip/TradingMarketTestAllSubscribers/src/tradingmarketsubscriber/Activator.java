package tradingmarketsubscriber;

import java.util.List;
import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import tradingmarketbuyerproducer.BuyerDatabase;
import tradingmarketcalculatorpublisher.Calculator;
import tradingmarketproducer.Company;
import tradingmarketproducer.TradeMarketDatabase;
import tradingmarketproducer.User;
import tradingmarketstatusproducer.StatusDatabase;

public class Activator implements BundleActivator {

    private ServiceReference<TradeMarketDatabase> serviceTradeMarketReference;
    private ServiceReference<BuyerDatabase> serviceBuyerReference;
    private ServiceReference<StatusDatabase> serviceStatusReference;
    private ServiceReference<Calculator> serviceCalculatorReference;

    private Scanner scanner;

    public void start(BundleContext bundleContext) throws Exception {
        System.out.println("Start subscriber service");
        
		try {
			
			serviceTradeMarketReference = bundleContext.getServiceReference(TradeMarketDatabase.class);
			TradeMarketDatabase tradeMarketDatabase = null;
			if (serviceTradeMarketReference != null) {
			    tradeMarketDatabase = bundleContext.getService(serviceTradeMarketReference);
			}

			serviceBuyerReference = bundleContext.getServiceReference(BuyerDatabase.class);
			BuyerDatabase buyerDatabase = null;
			if (serviceBuyerReference != null) {
			    buyerDatabase = bundleContext.getService(serviceBuyerReference);
			}

			serviceStatusReference = bundleContext.getServiceReference(StatusDatabase.class);
			StatusDatabase statusDatabase = null;
			if (serviceStatusReference != null) {
			    statusDatabase = bundleContext.getService(serviceStatusReference);
			}
			
			serviceCalculatorReference = bundleContext.getServiceReference(Calculator.class);
			Calculator calculator = null;
			if (serviceStatusReference != null) {
				calculator = bundleContext.getService(serviceCalculatorReference);
			}
//	        serviceTradeMarketReference = bundleContext.getServiceReference(TradeMarketDatabase.class);
//	        TradeMarketDatabase tradeMarketDatabase = bundleContext.getService(serviceTradeMarketReference);		
	        if (tradeMarketDatabase != null) {
	            System.out.println("Connected to TradingMarket service.");
	            System.out.println(tradeMarketDatabase.databaseRunner());
	        } else {
	            System.out.println("TradingMarket service not available.");
	        }
	
	        if (buyerDatabase != null) {
	            System.out.println("Connected to Buyer service.");
	            System.out.println(buyerDatabase.databaseRunner());
	        } else {
	            System.out.println("Buyer service not available.");
	        }
	
	        if (statusDatabase != null) {
	            System.out.println("Connected to Status service.");
	            System.out.println(statusDatabase.databaseRunner());
	        } else {
	            System.out.println("Status service not available.");
	        }
	        
	        if (calculator != null) {
	            System.out.println("Connected to calculator service.");
	            System.out.println(calculator.databaseRunner());
	        } else {
	            System.out.println("Calculator service not available.");
	        }
        
        scanner = new Scanner(System.in);

        String userInput;
        while (true) {
            System.out.println("\u001B[1m\u001B[33m============ Welcome To MiniTradingMarket =============\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 1 to Register\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 2 to Check Market Status\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 3 to Buy Strocks\u001B[0m");
            System.out.println("\u001B[1m\u001B[36mEnter 4 to Open Calculator\u001B[0m");
            System.out.println("\u001B[1m\u001B[31mEnter 5 to Quit\u001B[0m");
            System.out.println("\u001B[1m\u001B[33m=======================================================\u001B[0m");
            System.out.print("\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            userInput = scanner.nextLine();

            if (userInput.equalsIgnoreCase("1")) {
            	System.out.println("\t"+"\u001B[1m\u001B[29m============$$$$$$$$ Regiser Now $$$$$$$$==============\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 1 to Register User\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 2 to Register Company\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 3/4(Mockdata) to Check Connection\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[29m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputSetup;
            	userInputSetup = scanner.nextLine();
            	try {	
            		if(userInputSetup.equalsIgnoreCase("1")) {
            			// create new user
            			System.out.print("\u001B[1m\u001B[36mEnter your name here : \u001B[0m");
            			String userName;
            			userName = scanner.nextLine();
	            			boolean result = tradeMarketDatabase.createNewUser(userName);
	            			if(result) {
	                        	System.out.println("\u001B[1m\u001B[32mYour Are added to the system\u001B[0m");
	            			}else {
	                        	System.out.println("\u001B[1m\u001B[31mSomething wrong happend try againg ;( \u001B[0m");
	            			}
            		}else if(userInputSetup.equalsIgnoreCase("2")) {
            			// create new company
            	        System.out.print("\u001B[1m\u001B[36mEnter New company name here : \u001B[0m");
            	        String companyName;
            	        companyName = scanner.nextLine();

            	        System.out.print("\u001B[1m\u001B[36mEnter No of Stocks (eg:- 12): \u001B[0m");
            	        int noOfStocks;
            	        noOfStocks = scanner.nextInt();
            	        scanner.nextLine(); // consume newline character

            	        System.out.print("\u001B[1m\u001B[36mEnter Stock Per Price (eg:- 12.13): \u001B[0m");
            	        double perPrice;
            	        perPrice = scanner.nextDouble();
            	        scanner.nextLine(); // consume newline character
	            			boolean result = tradeMarketDatabase.createNewCompany(companyName,noOfStocks,perPrice);
	            			if(result) {
	                        	System.out.println("\u001B[1m\u001B[32mCompany is added to the system\u001B[0m");
	            			}else {
	                        	System.out.println("\u001B[1m\u001B[31mSomething wrong happend try againg ;( \u001B[0m");
	            			}
            		}else if(userInputSetup.equalsIgnoreCase("3")){
            			System.out.println(tradeMarketDatabase.databaseRunner());
            		}else if(userInputSetup.equalsIgnoreCase("4")){
            			System.out.println(tradeMarketDatabase.addMockUsers());
            			System.out.println(tradeMarketDatabase.addMockData());
            		}else {
//            			break;            			
            		}
            		}catch(Exception e) {
//            				e.printStackTrace();
            			System.out.println(e);
            			
            		}
            } else if (userInput.equalsIgnoreCase("2")) {
            	System.out.println("\t"+"\u001B[1m\u001B[29m============$$$$$$$$ Today Market $$$$$$$$=============\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 1 to See all Companies\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 2 to See all Users\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[32mEnter 3 to Check Connection\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[29m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputStatus;
            	userInputStatus = scanner.nextLine();
            	try {				
            		if(userInputStatus.equalsIgnoreCase("1")) {
	            			List<Company> companyList = statusDatabase.getAllCompanies();
	                     	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
	                     	System.out.println("\u001B[1m\u001B[29mCompanyId | CompanyName | #Stocks | PerPrice | #Holders\u001B[0m");
	            			for (Company company : companyList) {
	            	            System.out.print("\t"+company.getCompanyId()+ "\t");
	            	            System.out.print(company.getCompanyName()+ "\t");
	            	            System.out.print(company.getNoOfStocks()+ "\t");
	            	            System.out.print(company.getPerPrice()+ "\t");
	            	            System.out.print(company.getNoOfHolders());
	            	            System.out.println();
	            	        }
	                    	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
            		}else if(userInputStatus.equalsIgnoreCase("2")) {
            			List<User> userList = statusDatabase.getAllUsers();
                    	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
                     	System.out.println("\u001B[1m\u001B[29m	 UserId |  UserName  |  CompanyId  |  Number of Stocks\u001B[0m");
            			for (User user : userList) {
            	            System.out.print("\t"+user.getUserId()+ "\t");
            	            System.out.print(user.getUserName()+ "\t");
            	            System.out.print(user.getCompanyId()+ "\t");
            	            System.out.print(user.getNoOfStocks());
            	            System.out.println();
            	        }
                    	System.out.println("\u001B[1m\u001B[29m=======================================================\u001B[0m");
             		}else if(userInputStatus.equalsIgnoreCase("3")){
            			System.out.println(statusDatabase.databaseRunner());
            		}else {
//            			break
            		}
            	}catch(Exception e) {
//            				e.printStackTrace();
            		System.out.println(e);
            	}
            } else if (userInput.equalsIgnoreCase("3")) {
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======$$$$$$$$ Buying & Selling Stocks $$$$$$$$=======\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 1 to Buy Stocks\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 2 to Check Connection\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputBuyer;
            	userInputBuyer = scanner.nextLine();
            	try {				
            	if(userInputBuyer.equalsIgnoreCase("1")) {
            		
        	        System.out.print("\u001B[1m\u001B[36mEnter Buyer Id : \u001B[0m");
        	        int buyerId;
        	        buyerId = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        System.out.print("\u001B[1m\u001B[36mEnter Seller Id : \u001B[0m");
        	        int sellerId;
        	        sellerId = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        System.out.print("\u001B[1m\u001B[36mEnter Company Id : \u001B[0m");
        	        int companyId;
        	        companyId = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        System.out.print("\u001B[1m\u001B[36mEnter No of Stocks going to sell : \u001B[0m");
        	        int noOfStocks;
        	        noOfStocks = scanner.nextInt();
        	        scanner.nextLine(); // consume newline character
        	        
        	        boolean result = buyerDatabase.buyStocks(buyerId, sellerId, companyId, noOfStocks);
        			if(result) {
                    	System.out.println("\u001B[1m\u001B[32mYou bought the stocks\u001B[0m");
        			}else {
                    	System.out.println("\u001B[1m\u001B[31mSomething wrong happend try againg ;( \u001B[0m");
        			}
            	}else if(userInputBuyer.equalsIgnoreCase("2")) {
            		System.out.println(buyerDatabase.databaseRunner());
            	}else {
//            		break
            	}
            	}catch(Exception e) {
//    				e.printStackTrace();
            		System.out.println(e);
            	}
            }else if (userInput.equalsIgnoreCase("4")) {
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======$$$$$$$ Chose the Calculator Type $$$$$$$=======\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 1 to Select Monthly\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 2 to Select Annual\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[33mEnter 3 to Delete User\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[31mEnter any character to Quit from Registering\u001B[0m");
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
            	System.out.print("\t"+"\u001B[1m\u001B[37mEnter your response : \u001B[0m");
            	
            	String userInputType;
            	userInputType = scanner.nextLine();
            	try {
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
    	        
            	if(userInputType.equalsIgnoreCase("1")) {
            		
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the rate (eg:-12.5) : \u001B[0m");
                	float rate;
                	rate = scanner.nextFloat();
        	        scanner.nextLine(); 
        	        
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the value (eg:-123) : \u001B[0m");
        	        float value;
        	        value = scanner.nextFloat();
        	        scanner.nextLine();
            		
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the No Of months : \u001B[0m");
            		int noOfMonths;
            		noOfMonths = scanner.nextInt();
        	        scanner.nextLine();
        	        
        	        float result = calculator.getMonthlyInterestValue(value, noOfMonths, rate);
        	        System.out.println("\t" + "\u001B[1m\u001B[36m" + result + " $ for "+noOfMonths+" months\u001B[0m");
        	    
            	}else if(userInputType.equalsIgnoreCase("2")) {
            		
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the rate (eg:-12.5) : \u001B[0m");
                	float rate;
                	rate = scanner.nextFloat();
        	        scanner.nextLine(); 
        	        
                	System.out.print("\t"+"\u001B[1m\u001B[36mEnter the value (eg:-123) : \u001B[0m");
        	        float value;
        	        value = scanner.nextFloat();
        	        scanner.nextLine();
        	        
            		float result = calculator.getAnnualInterestValue(value, rate);
        	        System.out.println("\t" + "\u001B[1m\u001B[36m" + result + " $ for annually\u001B[0m");
            	}else if(userInputType.equalsIgnoreCase("3")) {
        	        System.out.print("\t" + "\u001B[1m\u001B[36mEnter UserId here To Delete : \u001B[0m");
        	  		int userId;
            		userId = scanner.nextInt();
        	        scanner.nextLine();
        	        
        	        boolean result = calculator.deleteUser(userId);
        			if(result) {
                    	System.out.println("\u001B[1m\u001B[32mUser "+userId+" is deleted\u001B[0m");
        			}else {
                    	System.out.println("\u001B[1m\u001B[31mSomething wrong happend try againg ;( \u001B[0m");
        			}
        			
            	}else {
//            		break;
            	}
            	System.out.println("\t"+"\u001B[1m\u001B[34m=======================================================\u001B[0m");
            	}catch(Exception e) {
//    				e.printStackTrace();
            		System.out.println(e);
            	}
            }else if (userInput.equalsIgnoreCase("5")){
            	break;    	
            }else {
//            	break;
            }
        	}
    	}catch(Exception e) {
//			e.printStackTrace();
    		System.out.println(e);
    	}
    }

    public void stop(BundleContext bundleContext) throws Exception {
        if (serviceTradeMarketReference != null) {
            bundleContext.ungetService(serviceTradeMarketReference);
        }
        if (serviceBuyerReference != null) {
            bundleContext.ungetService(serviceBuyerReference);
        }
        if (serviceStatusReference != null) {
            bundleContext.ungetService(serviceStatusReference);
        }
        System.out.println("Stop subscriber service");
    }
    
}
